import { chromium } from "playwright";

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
await page.goto("http://localhost:3000", { waitUntil: "domcontentloaded" });
await page.waitForSelector('[aria-label="Boop the site mascot"]');

const info = await page.evaluate(() => {
  const btn = document.querySelector('[aria-label="Boop the site mascot"]');
  const chain = [];
  let el = btn;
  while (el && el !== document.body) {
    chain.push(`${el.tagName} | ${String(el.className).slice(0, 70)}`);
    el = el.parentElement;
  }
  const banner = document.querySelector('[data-testid="hero-banner"]');
  const rb = banner.getBoundingClientRect();
  const bb = btn.getBoundingClientRect();
  const x = bb.x + bb.width / 2;
  const probes = [rb.bottom - 10, rb.bottom + 5, rb.bottom + 20, bb.bottom - 6].map((y) => {
    const hit = document.elementFromPoint(x, y);
    return {
      y: Math.round(y),
      hit: hit
        ? `${hit.tagName} | ${hit.getAttribute("aria-label") || String(hit.className).slice(0, 45)}`
        : null,
    };
  });
  const wrap = btn.parentElement.parentElement;
  return {
    chain,
    probes,
    bannerBottom: Math.round(rb.bottom),
    mascot: { top: Math.round(bb.top), bottom: Math.round(bb.bottom) },
    wrapper: { z: getComputedStyle(wrap).zIndex, pos: getComputedStyle(wrap).position },
  };
});

console.log(JSON.stringify(info, null, 2));
await browser.close();
