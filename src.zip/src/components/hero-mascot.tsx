"use client";

import { Mascot } from "page-mascot";

const SIZE = 128;

/**
 * Lain, the page mascot: a chibi bust that turns its head toward the pointer and
 * plays a reaction when clicked.
 *
 * She is only mounted once both sprite sheets exist on disk — `Home` checks for
 * them, so a missing asset leaves the banner exactly as it was rather than
 * reserving an empty clickable square. To draw her, see `characters/lain/PROMPTS.md`.
 */
export function HeroMascot() {
  return (
    <div className="pointer-events-none absolute right-2.5 bottom-0 z-20 translate-y-[24%] md:right-4">
      <div className="pointer-events-auto origin-bottom-right scale-[0.82] md:scale-100">
        <Mascot
          directions="/mascots/lain-directions.webp"
          reactions="/mascots/lain-reactions.webp"
          size={SIZE}
          label="site mascot"
          className="rounded-full focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
        />
      </div>
    </div>
  );
}
