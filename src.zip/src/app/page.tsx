import { existsSync } from "node:fs";
import path from "node:path";

import { About } from "@/components/about";
import { BottomBlur } from "@/components/bottom-blur";
import { Contact } from "@/components/contact";
import { Footer } from "@/components/footer";
import { Hero } from "@/components/hero";
import { Projects } from "@/components/projects";
import { SiteHeader } from "@/components/site-header";

const MASCOT_DIRECTIONS = path.join(
  process.cwd(),
  "public",
  "mascots",
  "lain-directions.webp",
);
const MASCOT_REACTIONS = path.join(
  process.cwd(),
  "public",
  "mascots",
  "lain-reactions.webp",
);

export default function Home() {
  // Build-time check: the mascot is only mounted once both sprite sheets exist,
  // so a missing asset never leaves an empty clickable square on the banner.
  const mascotReady =
    existsSync(MASCOT_DIRECTIONS) && existsSync(MASCOT_REACTIONS);

  return (
    <>
      <SiteHeader />
      <main
        id="main-content"
        tabIndex={-1}
        className="relative w-full scroll-mt-20"
      >
        <Hero mascotReady={mascotReady} />
        <About />
        <Projects />
        <Contact />
      </main>
      <Footer />
      <div id="page-end" aria-hidden="true" className="h-px w-full" />
      <BottomBlur />
    </>
  );
}
